VTE 1.0.10 修复包

源码目录：vte-1.0.10/
完整提交补丁：vte-1.0.10.patch
基准提交：d445074422a0a1c4a5c04ea2aa8b785d3e09a51d
修复提交：409da3a

已验证：Go 回归测试、竞态检测、go vet、前端生产构建、Linux amd64/arm64 编译。
未完成：GitHub 推送和 Docker 镜像发布；当前环境没有 GitHub 写入凭据。

上传方法（在你已登录 GitHub 的电脑上）：
1. git clone https://github.com/starared/vte.git
2. cd vte
3. git am /替换为补丁实际路径/vte-1.0.10.patch
4. git push origin main
5. git tag v1.0.10
6. git push origin v1.0.10

若应用补丁提示冲突，请先处理冲突，不要强制覆盖远端。
仓库已有 Docker 构建工作流，成功推送后还需检查 Actions 的执行结果。

升级注意：Compose 默认绑定 127.0.0.1，适合主机 Nginx 反代；直接 IP 访问请按需修改绑定地址。
已有管理员密码保留。新安装不再使用 admin123，初始密码在启动日志中。
完整变更见源码目录 CHANGELOG.md。
